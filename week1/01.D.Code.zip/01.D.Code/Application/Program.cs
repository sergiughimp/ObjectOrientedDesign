﻿// Declare and initialize variables
int apples = 10;
int oranges = 5;
int totalFruits;
totalFruits = apples + oranges;
double pricePerApple = 0.50;
double pricePerOrange = 0.75;

// Calculate total cost
double totalCost = (apples * pricePerApple) + (oranges * pricePerOrange);

Console.WriteLine("Total Cost:");
Console.WriteLine(totalCost);

// Apply discount
double discount = 2.0;
double finalCost = totalCost - discount; // Subtraction: finalCost = totalCost - 2.0

// Update the number of apples after some are sold
int applesSold = 4;
apples = apples - applesSold; // Subtraction: apples = 6

// Calculate average price per fruit
double averagePricePerFruit = totalCost / totalFruits;